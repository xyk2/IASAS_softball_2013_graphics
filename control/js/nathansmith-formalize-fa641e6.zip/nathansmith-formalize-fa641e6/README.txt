CREDITS

ExtJS port by Mike Wille:
- https://github.com/digerata

MooTools port by Ryan Florence:
- https://github.com/rpflorence

=====

Helpful bug reports filed by:
- https://github.com/wadewinningham
- https://github.com/tingletech
- https://stuartcharlton.com
- https://github.com/garrettdimon
- https://github.com/kdonald

=====

Licensed under MIT/GPL.

GPL license:
http://www.gnu.org/licenses/gpl.html

MIT license:
http://www.opensource.org/licenses/mit-license.php